package com.capg.OnlineShop.service;

import org.springframework.stereotype.Service;

@Service
public class ProdListServImpl implements IProductListService {
	
	

}
