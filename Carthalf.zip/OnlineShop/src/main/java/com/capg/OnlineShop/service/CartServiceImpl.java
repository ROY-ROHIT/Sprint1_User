package com.capg.OnlineShop.service;

import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.List;
//import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.OnlineShop.entities.Cart;
import com.capg.OnlineShop.entities.Product;
import com.capg.OnlineShop.entities.ProductList;
import com.capg.OnlineShop.repository.ICartRepository;
import com.capg.OnlineShop.repository.IProductListRepository;
import com.capg.OnlineShop.repository.IProductRepository;

@Service
public class CartServiceImpl implements ICartService {
	
	
	@Autowired
	private ICartRepository repo;
	@Autowired
	private IProductRepository prepo;
	@Autowired
	private IProductListRepository plrepo;

	@Override
	public Cart addProductToCart(Cart cart, int prodId, int quantity) {
		Product pr=prepo.findById(prodId).get();
//		pr.setQuantity(pr.getQuantity()-quantity);
//		prepo.save(pr);
		repo.save(cart);
		
		// TODO Auto-generated method stub
		return cart;
	}

	@Override
	public Cart removeProductFromCart(Cart cart, int prodId) {
		
		Product pr=prepo.findById(prodId).get();
		Cart cr=repo.findById(pr.getProductId()).get();
//		List<ProductList> pro=cr.getPlist();
		
//		repo.delete((Cart) pro);
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductList updateProductQuantity(int id, String name, int quantity) {
		
//		Product pr=prepo.findById(p.getProductId()).get();
//		pr.setQuantity(pr.getQuantity()+quantity);
//		prepo.save(pr);
//		repo.save(cart);
//
//		return cart;
//		int id=cart.getCartId();
		Cart cr=repo.findById(id).get();
		ProductList p=plrepo.findByProductName(name);
		p.setQuantity(quantity);
		return p;
		
	}

	@Override
	public Cart removeAllProducts(int id) {
		
//		Map<Product,Integer> product=(Map<Product, Integer>) cart.getPlist();
//		List<Product> p=new ArrayList<Product>();
//		for(Map.Entry<Product,Integer> m : product.entrySet())
//		{
//			 p=(List<Product>) m.getKey();
//		}
//		prepo.deleteAll(p);
		Cart cr=repo.findById(id).get();
//		List<ProductList> p= cr.getPlist();
		
		repo.delete(cr);
		
		return null;
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProductList> viewAllProducts(int id) {
		
//		Map<Product,Integer> product=cart.getProduct();
//		List<Product> p=new ArrayList<Product>();
//		for(Map.Entry<Product,Integer> m : product.entrySet())
//		{
//			 p=(List<Product>) m.getKey();
//		}
//		return p;
//		Cart cr=repo.findById(id).get();
		List<ProductList> p= (List<ProductList>) plrepo.findByFk_Id(id);
		return p;
		}
	

}
