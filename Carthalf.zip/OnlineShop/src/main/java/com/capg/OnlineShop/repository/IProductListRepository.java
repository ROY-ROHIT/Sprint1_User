package com.capg.OnlineShop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.OnlineShop.entities.ProductList;


@Repository
public interface IProductListRepository extends JpaRepository<ProductList,Integer> {
	
	public ProductList findByProductName(String name);
//	@Query("from Cart c inner join fetch c.cartId where r.reviewId = :id")
//	@Query("Select pl from product-list pl,cart c where pl.fk_id=c.Cart_Id")
	@Query("from product-list pl inner join fetch pl.fk_id where pl.fk_id=cart.Cart_Id")
	public List <ProductList> findByFk_Id(int fk_id);

}
