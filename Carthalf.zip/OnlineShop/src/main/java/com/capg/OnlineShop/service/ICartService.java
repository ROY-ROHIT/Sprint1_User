package com.capg.OnlineShop.service;

import java.util.List;

import com.capg.OnlineShop.entities.Cart;
//import com.capg.OnlineShop.entities.Product;
import com.capg.OnlineShop.entities.ProductList;

public interface ICartService {
	
	public Cart addProductToCart(Cart cart,int prodId,int quantity);
	public Cart removeProductFromCart(Cart cart,int prodId);
	public ProductList updateProductQuantity(int id, String name,int quantity);
	public Cart removeAllProducts(int id);
	public List<ProductList> viewAllProducts(int id);

}
