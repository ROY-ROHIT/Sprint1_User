package com.capg.OnlineShop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.OnlineShop.entities.Product;

public interface IProductRepository extends JpaRepository<Product, Integer> {

}
