package com.capg.OnlineShop.service;



public interface IProductListService {

}
