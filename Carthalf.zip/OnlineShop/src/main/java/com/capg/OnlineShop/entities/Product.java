package com.capg.OnlineShop.entities;

//import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//import com.cg.onlineshopping.entities.Review;

@Entity
@Table (name="Product")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {

	@Id
	@Column(name="PRODUCT_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	
	@Column(name="PRODUCT_NAME")
	private String productName;
	
	@Column(name="BRAND_NAME")
	private String brandName;
	
	@Column(name="CATEGORY")
	private String category;
	
	@Column(name="PRICE")
	private double price;
	
	@Column(name="COLOR")
	private String color;
	
	@Column(name="SPECIFICATION")
	private String specification;
	
	@Column(name="QUANTITY")
	private int quantity;  // quantity in hand or stock , not quantity ordered
	
	@Column(name="USER_RATINGS")
	private int userRatings;
	
}
