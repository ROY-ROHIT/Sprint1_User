package com.capg.OnlineShop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.OnlineShop.entities.Cart;
import com.capg.OnlineShop.entities.ProductList;
@Repository
public interface ICartRepository extends JpaRepository<Cart, Integer> {
//	public ProductList findByName(String name);

}
