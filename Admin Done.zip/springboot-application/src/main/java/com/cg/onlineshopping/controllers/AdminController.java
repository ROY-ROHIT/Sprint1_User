package com.cg.onlineshopping.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshopping.entities.Admin;
import com.cg.onlineshopping.services.IAdminService;

@RestController
//@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private IAdminService adminServ;
	
	@GetMapping("/alladmin")
	public List<Admin> RetrieveAllAdmin()
	{
		return adminServ.viewAllAdmin();
	}
	
	@GetMapping("/admin/{id}")
	public Admin RetrieveAdminById(@PathVariable("id") int id)
	{
		return adminServ.viewAdmin(id);
	}
	
	@PostMapping("/addadmin")
	public ResponseEntity<Admin> createAdmin (@RequestBody Admin admin)
	{
		Admin ad=adminServ.addAdmin(admin);
		return new ResponseEntity<Admin>(ad,HttpStatus.CREATED);
	}
	

}