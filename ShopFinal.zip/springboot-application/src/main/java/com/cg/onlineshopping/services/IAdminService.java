package com.cg.onlineshopping.services;

import java.util.List;

import com.cg.onlineshopping.entities.Admin;

public interface IAdminService {
	public Admin addAdmin(Admin admin);
	public List<Admin> viewAllAdmin();
	public Admin viewAdmin(int id);

}
