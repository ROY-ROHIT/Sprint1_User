package com.cg.onlineshopping.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineshopping.entities.Admin;
import com.cg.onlineshopping.repositories.AdminRepository;
@Service
public class AdminServiceImpl implements IAdminService{
	
	@Autowired
	private AdminRepository repo;

	@Override
	public Admin addAdmin(Admin admin) {
		
		// TODO Auto-generated method stub
		return repo.save(admin);
	}

	@Override
	public List<Admin> viewAllAdmin() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Admin viewAdmin(int id) {
		// TODO Auto-generated method stub
		Admin admin=repo.findById(id).get();
		return (admin);
	}


}
