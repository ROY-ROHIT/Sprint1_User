package com.cg.onlineshopping.services;

public interface IProductListService {

}

